package picodiploma.dicoding.moviecatalogue_submission2;

import android.content.Context;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import java.util.ArrayList;

public class AdapterRecycler extends RecyclerView.Adapter<AdapterRecycler.review> {
    private ArrayList<movielist> listmovie;
    private Context context;

    public AdapterRecycler(ArrayList<movielist> listmovie, Context context) {
        this.listmovie = listmovie;
        this.context = context;
    }
    class review extends RecyclerView.ViewHolder{
        TextView txtjudul, txtdetail;
        ImageView imgposter;

        private RelativeLayout relativeLayout;
        public review(View view){
        super(view);
        txtjudul = itemView.findViewById(R.id.tv_title);
        txtdetail = itemView.findViewById(R.id.tv_detail);
        imgposter = itemView.findViewById(R.id.img_film);
        relativeLayout =itemView.findViewById(R.id.relative_list);
        }
    }

    @NonNull
    @Override
    public AdapterRecycler.review onCreateViewHolder(@NonNull ViewGroup viewadapter, int i) {
        View view = LayoutInflater.from(viewadapter.getContext()).inflate(R.layout.list_film, viewadapter, false);
        return new review(view);
    }

    @Override
    public void onBindViewHolder(@NonNull AdapterRecycler.review reView, final int i) {
    reView.txtjudul.setText(listmovie.get(i).getTitle());
    reView.txtdetail.setText(listmovie.get(i).getDescription());
    reView.imgposter.setImageResource(listmovie.get(i).getImage());
        reView.relativeLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(context, detail_movie.class);
                movielist film = listmovie.get(i);
                intent.putExtra("items", film);
                v.getContext().startActivity(intent);
            }
        });

    }

    @Override
    public int getItemCount() { return listmovie.size(); }
}


