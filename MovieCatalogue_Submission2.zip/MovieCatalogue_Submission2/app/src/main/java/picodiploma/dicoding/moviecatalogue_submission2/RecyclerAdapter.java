package picodiploma.dicoding.moviecatalogue_submission2;

import android.content.Context;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import java.util.ArrayList;

public class RecyclerAdapter extends RecyclerView.Adapter<RecyclerAdapter.MyViewHolder> {

    private ArrayList<movielist> listFilm;
    private Context context;


    public RecyclerAdapter(Context context, ArrayList<movielist> film) {
        this.context = context;
        this.listFilm = film;
    }


    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.list_film, viewGroup, false);
        return new MyViewHolder(view);
}

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder viewHolder, final int i) {
        viewHolder.txtJudul.setText(listFilm.get(i).getTitle());
        viewHolder.txtDesc.setText(listFilm.get(i).getDescription());
        viewHolder.imgPoster.setImageResource(listFilm.get(i).getImage());
        viewHolder.rlPoster.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(context, detail_movie.class);
                movielist film = listFilm.get(i);
                intent.putExtra("items", film);
                v.getContext().startActivity(intent);
            }
        });

    }

    @Override
    public int getItemCount() {
        return listFilm.size();
    }

    public static class MyViewHolder extends RecyclerView.ViewHolder {
        TextView txtJudul, txtDesc;
        ImageView imgPoster;
        RelativeLayout rlPoster;

            public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            txtJudul = itemView.findViewById(R.id.tv_title);
            txtDesc = itemView.findViewById(R.id.tv_detail);
            imgPoster = itemView.findViewById(R.id.img_film);
            rlPoster =  itemView.findViewById(R.id.relative_list);
        }
    }
}
