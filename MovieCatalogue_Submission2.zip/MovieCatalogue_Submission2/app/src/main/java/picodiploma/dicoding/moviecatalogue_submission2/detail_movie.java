package picodiploma.dicoding.moviecatalogue_submission2;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

public class detail_movie extends AppCompatActivity {

    private ImageView imageView;
    private TextView txtJudulFilm, txtDetailFilm;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail_movie);
        movielist items = getIntent().getParcelableExtra("items");
        imageView = findViewById(R.id.img_detail_film);
        imageView.setImageResource(items.getImage());

        txtJudulFilm = findViewById(R.id.txt_detail_film);
        txtJudulFilm.setText(items.getTitle());

        txtDetailFilm = findViewById(R.id.txt_judul_film);
        txtDetailFilm.setText(items.getDescription());


    }
}
