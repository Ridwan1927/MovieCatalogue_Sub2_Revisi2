package picodiploma.dicoding.moviecatalogue_submission2;

import android.os.Parcel;
import android.os.Parcelable;

public class movielist implements Parcelable {

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeInt(this.image);
        dest.writeString(this.description);
        dest.writeString(this.title);

    }


    private int image;
    private String description;
    //private Parcel i;
    private String title;

    protected movielist(Parcel in){
    this.image = in.readInt();
    this.title = in.readString();
    this.description = in.readString();
    //    this.i = i;
    }


    public movielist() {
    }

    public int getImage() {
        return image;
    }

    public void setImage(int image) {
        this.image = image;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public static final Creator<movielist> CREATOR = new Creator<movielist>() {
        @Override
        public movielist createFromParcel(Parcel source) { return new movielist(source); }

        @Override
        public movielist[] newArray(int size) { return new movielist[size]; }
    };
}
