package picodiploma.dicoding.moviecatalogue_submission2;


import android.content.res.TypedArray;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import java.util.ArrayList;


/**
 * A simple {@link Fragment} subclass.
 */
public class UpComing extends Fragment {
    private RecyclerView recyclerView;
    private String[] dataName;
    private String[] dataDescription;
    private TypedArray dataPhoto;
    private RecyclerAdapter recyclerAdapter;
    private View view;
    private ArrayList<movielist> movies = new ArrayList<>();

    public UpComing() {
        // Required empty public constructor
    }
    private void addItem() {

        for (int i = 0; i < dataName.length; i++) {
            movielist film = new movielist();
            film.setImage(dataPhoto.getResourceId(i, -1));
            film.setTitle(dataName[i]);
            film.setDescription(dataDescription[i]);
            movies.add(film);
        }
    }

    private void prepare() {
        dataName = getResources().getStringArray(R.array.data_name);
        dataDescription = getResources().getStringArray(R.array.data_deskripsi);
        dataPhoto = getResources().obtainTypedArray(R.array.data_image);
    }


    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable
                             Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.fragment_upcoming, container, false);
        prepare();
        addItem();
        recyclerAdapter = new RecyclerAdapter(getContext(), movies);
        RecyclerView recyclerView = view.findViewById(R.id.recy_upcooming);
        recyclerView.setLayoutManager(new LinearLayoutManager(view.getContext()));
        //recyclerView.setHasFixedSize(true);
        recyclerView.setAdapter(recyclerAdapter);
        recyclerView.setHasFixedSize(true);
        return view;
        //recyclerView.setHasFixedSize(true);
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
    }

}
